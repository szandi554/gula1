package com.example;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

public class MainController {

    @FXML
    private TextField heightField;

    @FXML
    private ListView<String> resultList;

    @FXML
    private TextField sideField;

    @FXML
    private TextField volumeField;

    @FXML
    void onClickCalcButton(ActionEvent event) {
        startCalc();
    }

    void startCalc() {  
        if(sideField.getText().isEmpty()) {
            System.err.println("Hiba! Nem adtál meg oldalt!");
            return;
        }
        if(heightField.getText().isEmpty()) {
            System.err.println("Hiba! Nem adtál meg magasságot!");
            return;
        }
        double side = Double.parseDouble(sideField.getText());
        double height = Double.parseDouble(heightField.getText());

        Double volume = 1.0/3.0 * Math.pow(side, 2) * height;
        volumeField.setText(volume.toString());
    }

    @FXML
    void onClickSaveButton(ActionEvent event) {

    }

}
